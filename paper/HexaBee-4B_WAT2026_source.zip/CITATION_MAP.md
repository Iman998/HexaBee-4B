# Primary-source citation map

Each citation is attached to the method/model/claim that it supports. Citations to previous work do not substitute for evidence of this model's own training or results; those are documented by local data and training audits.

| Component | Primary source / manuscript key |
|---|---|
| Gemma 3 student, baselines and 27B translation teacher | [Gemma 3 Technical Report](https://arxiv.org/abs/2503.19786), `gemmateam2025gemma3` |
| DeepSeek-V3.1 source generation | [Official model card](https://huggingface.co/deepseek-ai/DeepSeek-V3.1), `deepseekai2025v31` |
| DeepSeek-V3 family | [Technical report](https://arxiv.org/abs/2412.19437), `deepseekai2024v3`; not mislabeled as a separate V3.1 report |
| Explicit language roles and multilingual QA motivation | [XHotpotQA](https://arxiv.org/abs/2608.27481), `barati2026xhotpotqa`; [TyDi QA](https://aclanthology.org/2020.tacl-1.30/), `clark-etal-2020-tydi`; [MKQA](https://aclanthology.org/2021.tacl-1.82/), `longpre-etal-2021-mkqa` |
| Continued pretraining motivation | [Don’t Stop Pretraining](https://aclanthology.org/2020.acl-main.740/), `gururangan-etal-2020-dont` |
| Complementary human-authored MT evaluation | [FLORES-101](https://aclanthology.org/2022.tacl-1.30/), `goyal-etal-2022-flores`; cited as future validation, not an experiment in this study |
| Multilingual target-language conditioning | [Johnson et al.](https://aclanthology.org/Q17-1024/), `johnson-etal-2017-googles` |
| Multilingual instruction data | BLOOMZ and Aya, `muennighoff-etal-2023-crosslingual`, `singh-etal-2024-aya` |
| Cross-language instruction/response pairing | CrossIn, `lin-etal-2025-crossin` |
| Instruction and translation supervision | CrossAlpaca, `ranaldi-etal-2024-empowering` |
| Question Translation Training | `zhu-etal-2024-question` |
| Translation-focused adaptation | [ALMA](https://openreview.net/forum?id=farT6XXntP), `xu2024a` |
| Decoded synthetic target supervision | [Sequence-Level Knowledge Distillation](https://aclanthology.org/D16-1139/), `kim-rush-2016-sequence` |
| LoRA | [LoRA paper](https://openreview.net/forum?id=nZeVKeeFYf9), `hu2022lora` |
| Training framework | [LLaMA-Factory](https://aclanthology.org/2024.acl-demos.38/), `zheng-etal-2024-llamafactory` |
| Adapter and model software | [PEFT 0.17.1](https://github.com/huggingface/peft/tree/v0.17.1), `huggingface2025peft`; [Transformers](https://aclanthology.org/2020.emnlp-demos.6/), `wolf-etal-2020-transformers` |
| AdamW | [Decoupled Weight Decay Regularization](https://openreview.net/forum?id=Bkg6RiCqY7), `loshchilov2019decoupled` |
| BLEU | [Papineni et al.](https://aclanthology.org/P02-1040/), `papineni-etal-2002-bleu` |
| chrF / chrF++ | [chrF](https://aclanthology.org/W15-3049/), `popovic-2015-chrf`; [chrF++](https://aclanthology.org/W17-4770/), `popovic-2017-chrf` |
| Reproducible metric settings | [SacreBLEU](https://aclanthology.org/W18-6319/), `post-2018-call` |
| TER | [Snover et al.](https://aclanthology.org/2006.amta-papers.25/), `snover-etal-2006-study` |
| COMET | [COMET](https://aclanthology.org/2020.emnlp-main.213/), `rei-etal-2020-comet`; [official wmt22-comet-da checkpoint](https://huggingface.co/Unbabel/wmt22-comet-da), `unbabel2022cometda` |
| LLM-based MT judgment | Kocmi and Federmann's evaluation/GEMBA papers, `kocmi-federmann-2023-large`, `kocmi-federmann-2023-gemba`; the present eight-part rubric is explicitly described as custom |
| Paired bootstrap | [Koehn](https://aclanthology.org/W04-3250/), `koehn-2004-statistical` |

Figure icons are original line-art geometry, with PDF/SVG sources. They do not reproduce company logos or require an external icon license. Names on teacher cards identify the recorded models. Optional Flaticon assets were not needed.
