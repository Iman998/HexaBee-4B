#!/usr/bin/env python3
"""Render the two conceptual paper figures as editable, publication-size vectors."""
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch, Circle, Rectangle

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'figures'
INK, MUTED, BORDER = '#172B4D', '#52647D', '#D7E1EE'
BLUE, TEAL, GOLD = '#245DD3', '#087F83', '#966316'
plt.rcParams.update({'font.family': 'DejaVu Sans', 'font.size': 8,
                     'text.color': INK, 'pdf.fonttype': 42, 'svg.fonttype': 'none'})


def panel(ax, x, y, width, height, fill='white', edge=BORDER, radius=.018):
    patch = FancyBboxPatch((x,y),width,height,
        boxstyle=f'round,pad=0,rounding_size={radius}',
        facecolor=fill,edgecolor=edge,linewidth=.8)
    ax.add_patch(patch)
    return patch


def label(ax, x, y, text, size=8, color=INK, bold=False, **kwargs):
    return ax.text(x,y,text,fontsize=size,color=color,
            weight='bold' if bold else 'normal',va=kwargs.pop('va','center'),**kwargs)


def arrow(ax, start, end, color=BLUE, scale=10):
    ax.add_patch(FancyArrowPatch(start,end,arrowstyle='-|>',
        mutation_scale=scale,lw=1.35,color=color,shrinkA=2,shrinkB=2))


def canvas(width, height):
    fig,ax=plt.subplots(figsize=(width,height))
    fig.subplots_adjust(left=.006,right=.994,top=.992,bottom=.008)
    ax.set(xlim=(0,1),ylim=(0,1));ax.axis('off')
    return fig,ax


def save(fig, stem):
    OUT.mkdir(exist_ok=True)
    for ext in ('pdf','svg','png'):
        fig.savefig(OUT/f'{stem}.{ext}',dpi=260,facecolor='white')
    plt.close(fig)


def three_stage_overview():
    fig,ax=canvas(6.35,3.05)
    panel(ax,.012,.883,.34,.101,INK,INK)
    label(ax,.03,.934,'BASE  ·  Gemma 3 4B IT',9,'white',True)
    label(ax,.392,.934,'THREE TRAINING STAGES',8.4,MUTED,True)
    xs=(.012,.356,.700);width=.288
    stages=[(TEAL,'01','Wikipedia adaptation','#F0F8F7'),
            (GOLD,'02','Multilingual supervision','#FCF8EF'),
            (BLUE,'03','Translation specialization','#F0F5FF')]
    for x,(color,number,title,tint) in zip(xs,stages):
        panel(ax,x,.224,width,.612,tint)
        label(ax,x+.023,.790,number,10,color,True)
        label(ax,x+.075,.790,'PHASE '+str(int(number)),7.8,color,True)
        label(ax,x+.023,.727,title,8.2,INK,True)
        ax.plot([x+.023,x+width-.023],[.682,.682],color=color,lw=1.3)
    # The units distinguish processed pretraining examples from SFT records.
    label(ax,.035,.628,'Encyclopedic text',8.8,bold=True)
    label(ax,.035,.563,'EN · FA · AR · ZH · ARZ',7.6,MUTED)
    label(ax,.035,.454,'3.40M',19,TEAL,True)
    label(ax,.035,.366,'processed examples',8.2,MUTED)
    label(ax,.035,.273,'Predict the next token',7.8,TEAL,True)
    # QA and translation shares sum to the phase-2 mixture.
    label(ax,.379,.617,'19.46M',15,GOLD,True)
    label(ax,.622,.614,'QA records',7,GOLD,True,ha='right')
    label(ax,.379,.539,'5.76M cross-language',7.8,MUTED)
    label(ax,.379,.440,'10.70M',15,BLUE,True)
    label(ax,.622,.437,'MT records',7,BLUE,True,ha='right')
    label(ax,.379,.365,'answer-text translations',7.7,MUTED)
    bar_x,bar_y,bar_width=.379,.297,.244
    qa_fraction=19458332/30153404
    ax.add_patch(Rectangle((bar_x,bar_y),bar_width*qa_fraction,.022,fc=GOLD,lw=0))
    ax.add_patch(Rectangle((bar_x+bar_width*qa_fraction,bar_y),bar_width*(1-qa_fraction),.022,fc=BLUE,lw=0))
    label(ax,bar_x,.257,'QA 64.5%',7,GOLD)
    label(ax,bar_x+bar_width,.257,'MT 35.5%',7,BLUE,ha='right')
    label(ax,.723,.628,'Parallel text pairs',8.8,bold=True)
    label(ax,.723,.559,'Source ⇄ target',9.1,BLUE,True)
    label(ax,.723,.454,'658,274',18,BLUE,True)
    label(ax,.723,.366,'forward / reverse records',7.8,MUTED)
    label(ax,.723,.273,'6 languages · 30 directions',7.5,BLUE,True)
    arrow(ax,(.301,.496),(.352,.496),TEAL)
    arrow(ax,(.645,.496),(.697,.496),BLUE)
    label(ax,.671,.433,'merge',6.7,BLUE,ha='center')
    # Continuation and merge boundaries are part of the method, not data edges.
    ax.plot([.034,.623],[.181,.181],color=GOLD,lw=1.5)
    ax.plot([.034,.034],[.181,.204],color=GOLD,lw=1.5)
    ax.plot([.623,.623],[.181,.204],color=GOLD,lw=1.5)
    label(ax,.329,.126,'Same LoRA adapter: initialize → continue',8,GOLD,True,ha='center')
    label(ax,.844,.174,'Fresh LoRA adapter',7.8,BLUE,True,ha='center')
    panel(ax,.711,.067,.266,.068,INK,INK,radius=.012)
    label(ax,.844,.101,'MERGE → HexaBee-4B',8.2,'white',True,ha='center')
    save(fig,'three_stage_overview')


def shared_answer_example():
    fig,ax=canvas(3.15,3.12)
    label(ax,.025,.968,'ONE ANSWER · TWO TRAINING TASKS',7.9,INK,True)
    cards=[(.020,.455,GOLD,'QA','Answering','#FCF7EC',
            'Answer in\nSpanish.','Which planet is\nknown as the\nRed Planet?','English question'),
           (.525,.455,BLUE,'MT','Translation','#EFF5FF',
            'Translate into\nSpanish.','Mars is known\nas the Red\nPlanet.','English answer text')]
    for x,w,color,code,title,tint,instruction,text,kind in cards:
        panel(ax,x,.348,w,.563,'white')
        panel(ax,x,.691,w,.220,tint,edge=tint)
        panel(ax,x+.025,.847,.092,.046,color,color,radius=.008)
        label(ax,x+.071,.870,code,7.2,'white',True,ha='center')
        label(ax,x+.135,.869,title,8.2,color,True)
        label(ax,x+.026,.808,'SYSTEM INSTRUCTION',6.4,MUTED,True)
        label(ax,x+.026,.746,instruction,8.3,color,linespacing=1.25)
        label(ax,x+.026,.645,kind,7.1,MUTED)
        label(ax,x+.026,.575,text,8.5,va='top',linespacing=1.4)
    arrow(ax,(.247,.342),(.425,.250),GOLD)
    arrow(ax,(.752,.342),(.575,.250),BLUE)
    panel(ax,.020,.028,.960,.216,INK,INK)
    label(ax,.5,.201,'SHARED TARGET · SPANISH',7.6,'#BDD7FF',True,ha='center')
    label(ax,.5,.112,'Marte es conocido como\nel planeta rojo.',10,'white',True,ha='center',linespacing=1.3)
    save(fig,'shared_answer_example')


if __name__ == '__main__':
    three_stage_overview()
    shared_answer_example()
    print('Built two refined conceptual figures in PDF, SVG, and PNG.')
