#!/usr/bin/env python3
"""Check the compiled anonymous manuscript without changing evaluation outputs."""
from pathlib import Path
import json
import re
import pymupdf

ROOT = Path(__file__).resolve().parents[1]
source = (ROOT / 'paper.tex').read_text()
aux = (ROOT / 'paper.aux').read_text()
log = (ROOT / 'paper.log').read_text(errors='replace')
biblog = (ROOT / 'paper.blg').read_text(errors='replace')
bib = (ROOT / 'references.bib').read_text()
doc = pymupdf.open(ROOT / 'paper.pdf')
texts = [page.get_text() for page in doc]
joined = '\n'.join(texts)

def label_page(label):
    match = re.search(r'\\newlabel\{' + re.escape(label) + r'\}\{\{[^}]*\}\{(\d+)\}', aux)
    assert match, f'Missing label: {label}'
    return int(match.group(1))

def heading_page(heading):
    pages = [i + 1 for i, text in enumerate(texts) if heading in text.splitlines()]
    assert len(pages) == 1, (heading, pages)
    return pages[0]

def citations(text):
    return {key for group in re.findall(r'\\cite\w*\{([^}]+)\}', text) for key in group.split(',')}

main_pages = label_page('sec:mainend')
limitations_page = heading_page('Limitations')
ethics_page = heading_page('Ethical Considerations')
assert main_pages <= 8
assert limitations_page > main_pages and ethics_page > main_pages
assert 'Overfull' not in log
assert 'undefined citations' not in log and 'undefined references' not in log
assert not re.search(r'LaTeX Warning: (Citation|Reference)', log)
assert 'Warning--' not in biblog
assert 'PCT-4B' not in joined and 'pct-4b' not in joined
assert not re.search(r'political|non.political', joined, re.I)
assert not re.search(r'/data/|/home/|hf_[A-Za-z0-9]{20,}', joined)
assert not any(list(page.annots() or []) for page in doc)
assert 'Gemma 3 4B IT' in joined
assert r'\usepackage[review]{acl}' in source
assert r'\author{Anonymous submission}' in source
assert r'\section{Related Work}' in source
assert 'barati2026xhotpotqa' in citations(source)
keys = set(re.findall(r'@\w+\s*\{([^,]+),', bib))
assert citations(source) <= keys
intro = source.split(r'\section{Introduction}')[1].split(r'\section{Related Work}')[0]
main = source.split(r'\section*{Limitations}')[0]
assert not re.search(r'\bseed\b|\bserialization\b|\bcheckpoint revision\b', main.replace('and serialization are in Appendix', 'are in Appendix'), re.I)
figures = re.findall(r'\\includegraphics(?:\[[^]]*\])?\{([^}]+)\}', source)
assert {'figures/method_overview.pdf','figures/three_stage_overview.pdf','figures/shared_answer_example.pdf'} <= set(figures)
assert len(figures) == 10 and all((ROOT / f).is_file() for f in figures)
inputs = re.findall(r'\\input\{([^}]+)\}', source)
all_tex = source + '\n'.join((ROOT / f).read_text() for f in inputs)
report = {
    'passed': True,
    'model_name': 'HexaBee-4B',
    'base_model': 'Gemma 3 4B IT',
    'main_content_pages': main_pages,
    'limitations_page': limitations_page,
    'ethical_considerations_page': ethics_page,
    'references_start_page': heading_page('References'),
    'appendix_start_page': label_page('app:ptdata'),
    'pdf_total_pages': len(doc),
    'cited_sources': len(citations(source)),
    'introduction_cited_sources': len(citations(intro)),
    'figure_count': len(figures),
    'table_count': len(re.findall(r'\\begin\{table\*?\}', all_tex)),
    'no_overfull_boxes': True,
    'no_unresolved_citations_or_references': True,
    'anonymous_review_style': True,
    'original_pdf_annotations_removed': True,
    'official_page_policy': 'https://aclrollingreview.org/cfp',
}
(ROOT / 'results/submission_checks.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report, indent=2))
