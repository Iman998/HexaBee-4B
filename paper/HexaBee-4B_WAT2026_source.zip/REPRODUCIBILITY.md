# Reproducibility

The manuscript uses the official ACL anonymous review style. The portable source ZIP contains the manuscript, bibliography, required style files, generated tables, editable vector figures, aggregate directional CSVs, and a Makefile. Run `make paper` with pdfLaTeX and BibTeX; no network, model weights, API credentials, or private training files are needed to typeset it.

The two conceptual diagrams can be regenerated with `python scripts/build_submission_figures.py` (Matplotlib). The other figures are included as PDF, SVG, and PNG. Recomputing the entire historical audit is an author-workspace operation and requires its archived evidence; those raw records are not part of the anonymous source ZIP.

Full automatic scoring covers 36,572 test items per system with SacreBLEU 2.5.1 and unbabel-comet 2.2.7 using `Unbabel/wmt22-comet-da`. The judge covers the same 300 content identities, ten per direction. Source/target codes and all 90 system/direction rows are in `results/all_direction_metrics.csv`. Rows are paired by content identity, not file order. The appendix specifies signatures, COMET truncation, zero-score recovery, and uncertainty estimation.

The numerical audit passes 693 checks over saved sufficient statistics, per-item metric scores, original judge JSON, the 10,000-replicate paired bootstrap, corpus counts, and adapter dimensions. It makes no generation or judge API calls. The PDF check reports 8 main pages, 34 cited sources, 10 figures, 25 tables, no unresolved references, and no overfull boxes.

Phase 2 has 30,153,404 records: 19,458,332 answering and 10,695,072 answer-text translation. Final bidirectional SFT has 658,274 records. The available phase-1 sources contain 11,395,061 raw text rows, distinct from the logged 3,399,664 processed training examples. These are record counts, not unique-article totals.

The study compares complete recorded systems. Synthetic references and model judging, differing inference prompts, historical data conflicts, COMET truncation, and missing ablations remain explicit limitations. No human-benchmark result, isolated causal answering benefit, or prompt-language invariance experiment is claimed.
