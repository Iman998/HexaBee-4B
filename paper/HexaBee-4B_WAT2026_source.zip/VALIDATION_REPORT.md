# Manuscript validation — 13 September 2026

PASS: 693 numerical, coverage, formula, identity, and citation checks.

The check reads saved sufficient statistics and individual metric scores, recovers original judge section scores, and reproduces the 10,000-replicate paired bootstrap. It does not rerun model generation or assert causal QA gains.

| System | BLEU | chrF | chrF++ | TER ↓ | COMET ×100 |
|---|---:|---:|---:|---:|---:|
| Gemma 3 4B IT | 40.70 | 58.91 | 57.11 | 51.40 | 85.88 |
| Gemma 3 12B IT | 50.54 | 68.70 | 66.83 | 38.89 | 88.20 |
| HexaBee-4B | 62.03 | 75.08 | 73.75 | 30.05 | 89.86 |

All 90 model/direction rows include the five full-test automatic metrics, judge-subset chrF++/TER/COMET, both holistic scores, and all 16 judge dimensions. Full automatic metrics cover 36,572 examples per model; judge metrics cover the same 300 identities per model.

Mathematics checks cover corpus BLEU/chrF/TER sufficient statistics, macro versus pooled aggregation, LoRA tensor dimensions and count, multiset record totals, all 30 prompt-language probability distributions, and direction-stratified paired uncertainty.

The source notebooks report 2,025,730 initial row records. Phase 2 contains 30,153,404 expanded records, including 19,458,332 QA records and 10,695,072 translations. Initial row counts are not unique Wikipedia article counts.

Citation checks establish bibliography consistency and coverage of named core methods. Primary-source attribution was also reviewed manually. Figure/table rendering is checked separately in the compiled PDF.

Material interpretation limits retained: synthetic test references and model judging; unequal recorded inference prompts; no QA-mixture ablation; COMET truncation at 512 encoder tokens; 1,961 historical Spanish-target QA directive conflicts.

Detailed machine-readable checks: `results/paper_validation.json`.
