# HexaBee-4B — anonymous manuscript source

**Six-Language Translation with Multilingual Answering and Bidirectional Supervision**

Run `make paper` with pdfLaTeX and BibTeX to build `paper.pdf`. The package contains every figure and table referenced by `paper.tex`, the bibliography, and the official ACL style files. It needs no network access, private data, credentials, or model weights.

The main content is 8 pages; Limitations and Ethical Considerations follow on page 9. References start on page 9 and the appendix on page 11. The complete paper is 25 pages. There are 34 cited sources, 10 figures, and 25 tables.

All 30 translation directions, six target-language summaries, three systems, both judge modes, and eight rubric dimensions are included. Aggregate numerical data are in `results/all_direction_metrics.csv`; raw texts and author-only provenance are excluded.

Editable figures are supplied in SVG as well as PDF/PNG. The two explanatory diagrams can be rebuilt using `python scripts/build_submission_figures.py` with Matplotlib. `scripts/check_submission.py` optionally checks the compiled PDF with PyMuPDF. Full numerical audit results are described in `VALIDATION_REPORT.md`; rerunning that historical audit requires the original author workspace.

See `REPRODUCIBILITY.md`, `CITATION_MAP.md`, and `WAT2026_TEMPLATE_NOTES.md` for settings, primary sources, and page-limit policy.
