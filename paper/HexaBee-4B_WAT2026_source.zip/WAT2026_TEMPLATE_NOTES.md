# WAT 2026 LaTeX template

WAT 2026's official format page says: "Participants must use the same format as AACL-IJCNLP 2026 papers and follow the same instructions in terms of the format." There is no WAT-specific class/template.

Use the official ACL style files in `acl-style-files/` (downloaded from https://github.com/acl-org/acl-style-files):

- `acl_latex.tex` — pdfLaTeX template and instructions
- `acl_lualatex.tex` — XeLaTeX/LuaLaTeX template
- `acl.sty`, `acl_natbib.bst`, `custom.bib`, `anthology.bib.txt`
- `formatting.md` — general ACL formatting instructions

Official links:

- WAT 2026 CFP/format: https://lotus.kuee.kyoto-u.ac.jp/WAT/WAT2026/index.html
- ACL style repository: https://github.com/acl-org/acl-style-files
- ACL style ZIP: https://github.com/acl-org/acl-style-files/archive/refs/heads/master.zip
- ACL Overleaf template: https://www.overleaf.com/latex/templates/association-for-computational-linguistics-acl-conference/jvxskxpnznfj

WAT 2026 dates (AoE): research paper deadline 2026-09-14; ARR commitment 2026-09-21; acceptance 2026-10-01; camera-ready 2026-10-12; workshop 2026-11-09 in Hengqin, China.

## Page-limit verification — 13 September 2026

WAT 2026 points to the AACL-IJCNLP 2026 format and instructions. The AACL call uses ARR submission policies. The ARR call allows at most **eight pages of main content**; **Limitations (required)** and **Ethical Considerations (optional)** may follow the conclusion outside this allowance. References and the appendix are also outside the main-content count. Limitations should remain an explicit section after the conclusion rather than being hidden in the appendix.

- [AACL-IJCNLP 2026 main call](https://2026.aaclnet.org/calls/main_conference_papers/)
- [ARR call and length policy](https://aclrollingreview.org/cfp)

The revised PDF has **8 pages of main content**. Both supplementary policy sections begin on page **9**, references on page **9**, and the appendix on page **11**. Its total length is **25 pages**. No font-size, margin, or line-spacing override is used to meet the limit. The research manuscript uses anonymous review mode. These are format checks; no conference submission has been made.
